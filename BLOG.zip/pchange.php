<?php

session_start();
// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");
// echo "Successfully connected to the server and successfully connected to the database blog";

error_reporting(0);

$id = $_SESSION['blogger_id'];
$username = $_SESSION['blogger_username'];
$get = mysql_fetch_array(mysql_query("SELECT * FROM blogger_info WHERE blogger_id = '$id'"));
$old_password = $get['blogger_password'];

if($_POST['edit']){
	
	$new_passowrd = $_POST['pass'];
	mysql_query("UPDATE blogger_info SET blogger_password = '$new_passowrd' WHERE blogger_id = '$id'");
	if($username == 'Admin'){
		header('location:Admin.php');
	}
	else{
	header('location:blogger.php');
	}
	
}

echo "
	<body style='background-image:url(comp1.jpg);'> 
	<div style = 'width:90% ; background-color:grey ; border:2px solid black ; padding: 20px'>
	<h2 style = ''><a href='blogger.php' style='text-decoration:none;color:black;font-size:25px'>Home</a></h2>
	<form action='' method='post'>
	<h1 style = 'color:black ; font-size:20px'>Old Password:  ".$old_password."</h1>
	<h1 style = 'color:black ; font-size:20px'>New Password:  
	<input type='password' name='pass' style='padding:3px'></h1>
	<input type='submit' name='edit' value='Edit'>
	
	</div>
	</body>
	";

?>