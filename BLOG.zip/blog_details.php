<?php

session_start();
// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");

error_reporting(0);

$blogger_id = $_SESSION['blogger_id'];
$check = mysql_fetch_array(mysql_query("SELECT * FROM blogger_info WHERE blogger_id = '$blogger_id'"));

if($check['blogger_permission'] == 'no'){
	die("YOU DO NOT HAVE PERMISSION TO CREATE NEW BLOG.<a href='blogger.php'>Back</a>.");
}
$checkprev = mysql_fetch_array(mysql_query("SELECT * FROM blog_detail WHERE blog_id = '$bid'"));
if($checkprev['blog_detail_image'] == NULL){
echo "
 <body style='background-image:url(comp1.jpg);'>
<div style = 'width:90% ; background-color:grey ; border:2px solid black ; padding: 20px'>
		<h2 style = ''><a href='blogger.php' style='text-decoration:none;color:white;font-size:20px'>Home</a></h2>
		<form action='' method='post'>
		<table>
			<tr>
				<td>
					<b>Blog ID:</b>
				</td>
				<td>
					<input type='text' name='blog_id' style='padding: 3px'>
				</td>
			</tr>
			
			<tr>
				<td>
					<b>Blog Image URL:</b>
				</td>
				<td>
					<input type='text' name='blog_image' style='padding: 3px'>
				</td>
			</tr>
			
			<tr>
				<td>
					<input type='submit' name='add' value='add'>
				</td>
			</tr>
			
		</table>
</div>
</body>
";
}
if($_POST['add']){
	
	
		$id = $_POST['blog_id'];
		$check2 = mysql_fetch_array(mysql_query("SELECT * FROM blogs WHERE blog_id = '$id'"));
		
		if($check2 == 0){
			die("NO SUCH BLOG EXISTS. ENTER A VALID ID. <a href='blod_details.php'>Back</a>
			<br>CLICK <a href='blogger.php'>Here</a> TO VIEW YOUR WALL.");
		}
		if($check['blogger_id'] != $blogger_id){
			die("THAT BLOG DOESN'T BELONGS TO YOU. <a href='blog_details.php'>Back</a>
			<br>CLICK <a href='blogger.php'>Here</a> TO VIEW YOUR WALL.");
		}
		
	$bid = $_POST['blog_id'];
	$bimage = mysql_real_escape_string($_POST['blog_image']);
	
	mysql_query("INSERT INTO blog_detail (blog_id , blog_detail_image) VALUES ('$bid' , '$bimage')");
	
	header('location:blogger.php');
}
		

?>