<?php

session_start();
// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");

error_reporting(0);

$id = $_SESSION['blogger_id'];
$username = $_SESSION['blogger_username'];

if($username == ''){
header('location:login.php');
}

echo "
 
<body style=' background-image:url(comp1.jpg);'>
<div style = 'padding-left:30px'>
<div style = 'background-color:black ; width:100% ; height:2%'>
	<table>
		<tr>
			<td style = 'font-size:25px ; color:white ; text-align:left ; padding-top:25px ; padding-left:1000px'>Logged in as 
			<a href='admin.php' style='text-decoration:none ; color:white ; font-size:25px'>ADMIN</a>. </td>
		</tr>
	</table>
</div>

<div style = 'background-color:black ; width:100% ; height:8%'>
	<table style='padding-left:35px; padding-right:35px; padding-top:15px; padding-bottom:10px'>
		<tr>
		
			<td style='text-align:left ; width:150px'>
				<a href='blogger_settings.php' style='text-decoration:none ; color:white ; font-size:20px'>Options</a>
			</td>
		
			<td style='text-align:left ; width:150px'>
				<a href='users.php' style='text-decoration:none ; color:white ; font-size:20px'>Bloggers</a>
			</td>
			
			<td style='text-align:left ; width:220px'>
				<a href='permission.php' style='text-decoration:none ; color:white ; font-size:20px'>Edit Permissions</a>
			</td>
			<td style='text-align:left ; width:150px'>
				<a href='logout.php' style='text-decoration:none ; color:white ; font-size:20px'>Logout</a>
			</td>
			
		</tr>
	</table>
</div>


</div>

";

$sql = "SELECT * FROM blogs";

$records = mysql_query($sql);

$a = 1;

while($row = mysql_fetch_assoc($records)){
	
	$b_id = $row['blog_id'];
	$a++;
	if($a == '2'){
		echo"
		<div style='padding-top:10px ; padding-left:30px'>
		<div style='background-color:black ; height:8% ; width:200px'>
			<h3 style='color:white ; text-align:center ; padding-top:10px'>BLOGS</h3>
		</div>
		</div>

		";
	}
	echo "
	<div style='padding-top:10px ; padding-left:30px'>
	<div style = 'width:80% ; background-image:url(bpattern.jpg) ; border:1px solid black ; padding: 20px'>
		<h1 style = 'color:white ; font-size:20px ; padding:7px'>BLOG ID:  ".$row['blog_id']."</h1>
		<h1 style = 'color:white ; font-size:20px ; padding:7px'>BLOG AUTHOR:  ".$row['blog_author']."</h1>
		<h1 style = 'color:white ; font-size:20px ; padding:7px'>BLOG TITLE:  ".$row['blog_title']."</h1>
		<h1 style = 'color:white ; font-size:20px ; padding:7px'>BLOG CATEGORY:  ".$row['blog_category']."</h1>
		<h1 style = 'color:white ; font-size:20px ; padding:7px'>BLOG DESCRIPTION:  ".$row['blog_desc']."</h1>
		<h1 style = 'color:yellow ; font-size:16px ; padding:7px'>BLOG ACTIVE:  ".$row['blog_is_active']."</h1>
		<h1 style = 'color:yellow ; font-size:16px ; padding:7px'>BLOG CREATION DATE:  ".$row['creation_date']."</h1>
		<h1 style = 'color:yellow ; font-size:16px ; padding:7px'>BLOG UPDATED DATE:  ".$row['updated_date']."</h1>
		<h1 style = 'color:white ; font-size:16px ; padding:7px'>Blog Display Permission: <a href='admin.php?id=".$row['blog_id']."' style='text-decoration:none ;color:white; background-colour: yellow;'> ".$row['disp_permission']." (CHANGE? then click here!)</a> </h1>
		<br/>
	
	";
	
	$bid = $row['blog_id'];
		$records1 = mysql_fetch_array(mysql_query("SELECT * FROM blog_detail WHERE blog_id = $bid"));
		
		if($records1['blog_detail_image'] == NULL){
			echo"<br /> <br />
			<form action='blog_details.php' method='post'>
		<table>
			<tr>
				<td>
					<input type='submit' name='Add Blog Details' value='Add Image' >
				</td>
			</tr>
			</form>
		</table>
			</div></div>";
		}
		else{
			echo "
			<br /> <br />
			";
			$images = $records1['blog_detail_image'];
			echo " <img src='$images'>
			<br /> </div></div>";
		}
		
		if($row['disp_permission'] == 'no'){
			if(isset($_GET['id'])){
			$blog_id=$_GET['id'];
			mysql_query("UPDATE blogs SET disp_permission = 'yes' WHERE blog_id = '$blog_id'");
		}}
		else{
			if(isset($_GET['id'])){
			$blog_id=$_GET['id'];
			mysql_query("UPDATE blogs SET disp_permission = 'no' WHERE blog_id = '$blog_id'");
		}}
			//echo"<div style=' padding-left:30px'>
			//	<div style = 'width:80% ; background-image:url(bpattern.jpg) ; border:1px solid black ; color:white ; padding: 20px'><br /> <br />
			//<form action='admin.php' method='post'>
			//	  <input type='checkbox' name='Display' value='Display'> Display and post Blog. 
			//	  <input type='checkbox' name='NotDislay' value='NotDisplay' checked>No Display<br><br>
			//	  <input type='submit' value='Post'>
			//	</form>
		//</div></div>";}
		//if($_POST['Display']){
			
}

if($a == '1'){

	echo "
		<div style = 'padding-left:30px'>
		<div style='background-color:grey; height:8% ; width:400px'>
			<h3 style='color:black ; text-align:center ; padding-top:10px'>NO BLOGS TO DISPLAY</h3>
		</div>
		</div>
		";

}

$b = 1;

$q = "SELECT * FROM viewer_contact_info";

$r = mysql_query($q);

while($x = mysql_fetch_assoc($r)){

	$b++;
	if($b == '2'){
		echo"
		<div style='padding-top:10px ; padding-left:30px'>
		<div style='background-color:black ; height:8% ; width:200px'>
			<h3 style='color:white ; text-align:center ; padding-top:10px'>CONTACTS</h3>
		</div>
		</div>

		";
	}

	echo "
	<div style='padding-top:10px ; padding-left:30px'>
	<div style = 'width:40% ; background-image:url(comp2.jpg) ; border:1px solid black ; padding: 20px'>
		<h1 style = 'color:black ; font-size:20px ; padding:7px'>NAME:  ".$x['viewer_name']."</h1>
		<h1 style = 'color:black ; font-size:20px ; padding:7px'>CONTACT NO.:  ".$x['viewer_phn_no']."</h1>
		<h1 style = 'color:black ; font-size:20px ; padding:7px'>EMAIL_ID:  ".$x['viewer_email_id']."</h1>
	</div>
	</div>
	
	";
}

if($b == '1'){

	echo "
		<div style = 'padding-left:30px'>
		<div style='background-color:grey ; height:8% ; width:400px'>
			<h3 style='color:black ; text-align:center ; padding-top:10px'>NO CONTACTS FROM VIEWERS</h3>
		</div>
		</div></body>
		";

}


?>
