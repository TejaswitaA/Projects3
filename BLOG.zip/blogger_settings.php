<?php

session_start();
// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");


error_reporting(0);

$id = $_SESSION['blogger_id'];
$username = $_SESSION['blogger_username'];

echo "
<body style='background-image:url(comp1.jpg);'> 
<div style = 'padding-left:30px'>

<div style = 'background-color:black ; width:100% ; height:2%'>
	<table>
		<tr>
			<td style = 'font-size:25px ; color:white ; text-align:right ; padding-top:25px ; padding-left:950px'>Logged in as 
			<a href='blogger.php' style='text-decoration:none ; color:white ; font-size:25px'>".$username."</a>.</td>
		</tr>
	</table>
</div>
<div style = 'background-color:black ; width:100% ; height:10%'>
	<table style='padding-left:35px; padding-right:35px; padding-top:25px; padding-bottom:10px'>
		<tr>
			<td style='text-align:left ; width:150px'>
				<a href='logout.php' style='text-decoration:none ; color:white ; font-size:20px'>Logout</a>
			</td>
		</tr>
	</table>
</div>
</div>

<div style='padding-top:10px ; padding-left:30px'>
		<div style='background-color:black ; height:42% ; width:200px'>
			<h3 style='color:white ; text-align:left ; padding-top:20px ; padding-left:10px'>
			<a href='create.php' style='text-decoration:none ; color:white ; font-size:20px'>Create Blog</a></h3>
			<h3 style='color:white ; text-align:left ; padding-top:10px ; padding-left:10px'>
			<a href='delete.php' style='text-decoration:none ; color:white ; font-size:20px'>Delete Blog</a></h3>
			<h3 style='color:white ; text-align:left ; padding-top:10px ; padding-left:10px'>
			<a href='update.php' style='text-decoration:none ; color:white ; font-size:20px'>Update Blog</a></h3>
			<h3 style='color:white ; text-align:left ; padding-top:10px ; padding-left:10px'>
			<a href='pchange.php' style='text-decoration:none ; color:white ; font-size:20px'>Edit Password</a></h3>
			<h3 style='color:white ; text-align:left ; padding-top:10px ; padding-left:10px'> ";
			if($username != 'Admin'){
				echo " <a href='delete_account.php' style='text-decoration:none ; color:white ; font-size:20px'>Delete Account</a></h3> ";
			}
		echo "</div>
</div>
</body>
";

?>