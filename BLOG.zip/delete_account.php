<?php

session_start();
// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");
// echo "Successfully connected to the server and successfully connected to the database blog";

error_reporting(0);

$id = $_SESSION['blogger_id'];
$username = $_SESSION['blogger_username'];
$records = mysql_fetch_array(mysql_query("SELECT * FROM blogs WHERE blogger_id = $id"));

	mysql_query("DELETE FROM blogger_info WHERE blogger_id = $id");
	mysql_query("DELETE FROM blogs WHERE blogger_id = $id");
	$delete = $record['blog_id'];
	//while($row = mysql_fetch_assoc($records)){
	mysql_query("DELETE FROM blog_detail WHERE blog_id = $delete");
	//}

header('location:index.php');

?>