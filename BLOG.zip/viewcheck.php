<?php

// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");

//echo "Successfully connected to the server and successfully connected to the database blog";

error_reporting(0);

echo "

<body style = 'background-image:url(comp2.jpg) ; '>
<div style='padding-left:30px'>
	<div style = 'padding-left:90px ;padding-top:10px; width:95% ; height:1.5%'>
	<h2 style = ''><a href='blogger.php' style='text-decoration:none;color:black;font-size:25px'>Home</a></h2>
		<form action='author_details.php' method='post'>
		<table>
			<tr>
				<td>
					<b>Blogger Name:</b>
				</td>
				<td>
					<input type='text' name='name' style='padding: 3px'>
				</td>
			</tr>
			
			<tr>
				<td>
					<input type='submit' name='details' value='details'>
				</td>
			</tr>
			
		</table>
</div>
</body>
";
?>