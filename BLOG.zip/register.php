<?php


// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");
// echo "Successfully connected to the server and successfully connected to the database blog";

error_reporting(0);

if($_POST['register']){
	
	$username = mysql_real_escape_string($_POST['username']);
	$password = mysql_real_escape_string($_POST['password']);
	
	if(strlen($username) == 0){
		die("USERNAME IS REQUIRED. <a href='register.php'>Back</a>");
	}
	
	if(strlen($password) == 0){
		die("PASSWORD IS REQUIRED. <a href='register.php'>Back</a>");
	}
	
	$check = mysql_fetch_array(mysql_query("SELECT * FROM blogger_info WHERE username = '$username'"));
	
	if($check != 0){
		die("THAT USERNAME ALREADY EXISTS !!! TRY ANOTHER ONE. <a href='register.php'>Back</a>"); 
	}
	
	if(!ctype_alnum($username)){
		die("SPECIAL CHARACTERS ARE NOT ALLOWED IN USERNAME !!! <a href='register.php'>Back</a>");
	}
	
	if(strlen($username) > 20 ){
		die("USERNAME SHOULDN'T EXCEED 20 CHARACTERS. <a href='register.php'>Back</a>");
	}
	
	if(strlen($password) < 6){
		die("PASSWORD SHOULD BE 6-10 CHARACTERS LONG. <a href='register.php'>Back</a>");
	}
	time();
	$mysqldate = date( 'Y-m-d', time());	
	mysql_query("INSERT INTO blogger_info (blogger_username,blogger_password,blogger_creation_date,blogger_permission) VALUES ('$username' , '$password' , '$mysqldate' , 'no')");
	
	
	if($username == 'Admin'){
		mysql_query("UPDATE blogger_info SET blogger_permission = 'yes'");
	}
	
	header('location:index.php');
	
	
}

echo "

<body style ='padding-left:50px; background-image:url(comp1.jpg);'>
	<br/><br/><br/><br/><br/><br/><br/><br/>
	<div style='width:90% ; background-image:url(comp2.jpg) ; border:2px solid black ; padding: 20px;'>
	<u><h2 style = ''><a href='index.php' style='text-decoration:none;color:black;font-size:25px'>Home</a></h2></u>
		<h1 style = 'color:white'>REGISTER</h1>
		<form action='' method='post'>
		<table>
			<tr>
				<td>
					<b>Username:</b>
				</td>
				<td>
					<input type='text' name='username' style='padding: 3px'>
				</td>
			</tr>
			
			<tr>
				<td>
					<b>Password:</b>
				</td>
				<td>
					<input type='password' name='password' style='padding: 3px'>
				</td>
			</tr>
			<tr></tr>
			<tr></tr>
			<tr>
				<td>
					<input type='submit' name='register' value='sign up'>
				</td>
			</tr>
			
		</table>
	</div>
</body>
";

?>
