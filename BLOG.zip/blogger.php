<?php 
session_start();
// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");

error_reporting(0);


$id = $_SESSION['blogger_id'];
$username = $_SESSION['blogger_username'];

if($username == ''){
header('location:login.php');
}

echo "
<body style='background-image:url(comp1.jpg);'>
<div style = 'padding-left:30px'>

<div style = 'background-color:black ; width:100% ; height:1.5%'>
	<table>
		<tr>
			<td style = 'font-size:25px ; color:white ; text-align:left ; padding-top:30px ; padding-left:950px'>Logged in as 
			<a href='blogger.php' style='text-decoration:none ; color:white ; font-size:25px'>".$username."</a>.</td>
		</tr>
	</table>
</div>
<div style = 'background-color:black ; width:100% ; height:10%'>
	<table style='padding-left:35px; padding-right:35px; padding-top:25px; padding-bottom:10px'>
		<tr>
			<td style='text-align:center ; width:150px'>
				<a href='blogger_settings.php' style='text-decoration:none ; color:white ; font-size:20px'>Options</a>
			</td>
			<td style='text-align:center ; width:150px'>
				<a href='logout.php' style='text-decoration:none ; color:white ; font-size:20px'>Logout</a>
			</td>
		</tr>
	</table>
</div>
</div>

";



$sql = "SELECT * FROM blogs WHERE blogger_id = '$id'";

$records = mysql_query($sql);

$a = 1;

while($row = mysql_fetch_assoc($records)){

	$a++;
	if($a == '2'){
		echo"
		<div style='padding-top:10px ; padding-left:30px'>
		<div style='background-color:black ; height:8% ; width:200px'>
			<h3 style='color:white ; text-align:center ; padding-top:10px'>MY BLOGS</h3>
		</div>
		</div>

		";
	}
	echo "
	<div style='padding-left:30px ; padding-top:20px'>
	<div style = 'width:90% ; background-color:grey ; border:1px solid black ; padding: 20px'>
		<h1 style = 'color:black ; font-size:20px ; padding:7px ; padding-left:20px'>BLOG ID:  ".$row['blog_id']."</h1>
		<h1 style = 'color:black ; font-size:20px ; padding:7px ; padding-left:20px'>BLOG TITLE:  ".$row['blog_title']."</h1>
		<h1 style = 'color:black ; font-size:20px ; padding:7px ; padding-left:20px'>BLOG CATEGORY:  ".$row['blog_category']."</h1>
		<h1 style = 'color:black ; font-size:20px ; padding:7px ; padding-left:20px'>BLOG DESCRIPTION:  ".$row['blog_desc']."</h1>
		<h1 style = 'color:black ; font-size:20px ; padding:7px ; padding-left:20px'>BLOG AUTHOR:  ".$row['blog_author']."</h1>
		<h1 style = 'color:black ; font-size:20px ; padding:7px ; padding-left:20px'>BLOG ACTIVE:  ".$row['blog_is_active']."</h1><br/>
	
	
	";
		$bid = $row['blog_id'];
		$records1 = mysql_fetch_array(mysql_query("SELECT * FROM blog_detail WHERE blog_id = $bid"));
		
		if($records1['blog_detail_image'] == NULL){
			echo"<br /> <br />
			<form action='blog_details.php' method='post'>
		<table>
			<tr>
				<td>
					<input type='submit' name='Add Blog Details' value='Add Image' >
				</td>
			</tr> 
		</table>
			</div></div><br/><br/>";
		}
		else{
			echo "
			<div style='padding-left:30% ;'>
			<div style = 'width:90%; padding: 20px'>
			<br /> <br />
			";
			$images = $records1['blog_detail_image'];
			echo " <img src='$images'>
			<br /> </div></div></div></div>";
		}
	}

if($a == '1'){

	echo "
		<div style = 'padding-left:30px'>
		<div style='background-color:grey; height:8% ; width:400px'>
			<h3 style='color:black ; text-align:center ; padding-top:10px'>NO BLOGS TO DISPLAY</h3>
		</div>
		</div></body>
		";
		

}

?>
