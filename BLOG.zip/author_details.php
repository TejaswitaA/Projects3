<?php

// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");

error_reporting(0);

if(isset($_GET['id'])){
	$username=$_GET['id'];


	echo "
<body style='background-image:url(comp1.jpg);'>
	<div style='padding-left:30px'>
		<div style = 'padding-left:30px ;padding-top:10px; background-color:black; width:95.1% ; height:1.5%'>
			<table>
				<tr>
					<td style='text-align:right ; width:1200px'>
						<a href='login.html' style='text-decoration:none ; color:white ; font-size:20px'>LOGIN</a>
					</td>
				</tr>
				<tr>
					<td style='text-align:right ; width:1200px'>
						<a href='register.php' style='text-decoration:none ; color:white ; font-size:20px'>REGISTER</a>
					</td>
				</tr>
			</table>
		</div>
		<div style = 'background-color:black ; width:97.45% ; height:8%'>
		<table style='padding-top:15px; padding-bottom:10px'>
			<tr>
				<td style='text-align:center ; width:150px'>
					<a href='index.php' style='text-decoration:none ; color:white ; font-size:20px'>Home</a>
				</td>
				<td style='text-align:center ; width:150px'>
					<a href='contact.php' style='text-decoration:none ; color:white ; font-size:20px'>Contact Us</a>
				</td>
			</tr>
		</table>
	</div>
	</div>
	</body>
	";
	
$sql = "SELECT * FROM blogger_info WHERE blogger_username = '$username'";
$row1 = mysql_fetch_array(mysql_query($sql));
$sqll = $row1['blogger_id'];
$row = "SELECT * FROM blogs WHERE blogger_id = '$sqll'";

$records = mysql_query($row);

$a = 1;

while($row = mysql_fetch_assoc($records)){

	$a++;
	if($a == '2'){
		echo"
		<body>
		<div style='padding-top:10px ; padding-left:30px; align:center;'>
		<div style='background-color:black ; height:8% ; width:200px; align:center ;'>
			<h3 style='color:white ; text-align:center ; padding-top:10px;'>BLOGGERS</h3>
		</div>
		</div>
		";
	}
	
	echo "
	<div style='padding-top:10px ; padding-left:30px'>
	<div style = 'width:60% ; background-image:url(bpattern.jpg); padding: 20px; color:white; align:center;'>
		    <h1 style = 'color:white ; font-size:20px ; padding:7px'>Blog ID:  ".$row['blog_id']."</h1>
			<h1 style = 'color:white ; font-size:20px ; padding:7px'>BLog TITLE:  ".$row['blog_title']."</h1>
			<h1 style = 'color:white ; font-size:20px ; padding:7px'>Blog DESCRIPTION:  ".$row['blog_desc']."</h1>
			<h1 style = 'color:yellow ; font-size:17px ; padding:7px'>BLog AUTHOR:  ".$row['blog_author']."</h1>
			<h1 style = 'color:yellow ; font-size:17px ; padding:7px'>Blog DATE:  ".$row['creation_date']."</h1>
			<h1 style = 'color:yellow ; font-size:17px ; padding:7px'>Blog DATE:  ".$row['updated_date']."</h1>
			</div>
		</div>";
}		
	if($a == '1'){

	echo "
		<div style = 'padding-left:30px'>
		<div style='background-color:grey ; height:8% ; width:400px'>
			<h3 style='color:black ; text-align:center ; padding-top:10px'>NO BLOGGERS TO DISPLAY</h3>
		</div>
		</div></body>
		";
	}
}
?>