<?php

session_start();
// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");
// echo "Successfully connected to the server and successfully connected to the database blog";

error_reporting(0);

        session_unset();
		session_destroy();
		session_start();
if($_POST['login']){
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	$check = mysql_fetch_array(mysql_query("SELECT * FROM blogger_info WHERE blogger_username = '$username'"));
	if($check == 0){
		die("NO SUCH ACCOUNT EXISTS. CLICK <a href='register.php'>Here</a> TO REGISTER NOW.");
	}
	
	if($check['blogger_password'] != $password){
		die("INCORRECT PASSWORD !!! LOGIN AGAIN <a href='login.php'>Here</a>.");
	}
	$id = $check['blogger_id'];
	mysql_query("UPDATE blogger_info SET blogger_is_active = 'yes' WHERE blogger_username = '$username'");
	
	mysql_query("UPDATE blogs SET blog_is_active = 'yes' WHERE blogger_id = '$id'");
	
	time();
	$mysqldate = date( 'Y-m-d', time());
	
	mysql_query("UPDATE blogger_info SET blogger_updated_date = '$mysqldate' WHERE blogger_username = '$username'");

	$_SESSION['blogger_username'] = $username;
	$_SESSION['blogger_id']=$check['blogger_id'];
    $_SESSION['blogger_password']=$password;
	
	if($username == 'Admin'){
		header('location:admin.php');
	}
	else{
		header('location:blogger.php');
	}
}

echo "

<body style ='padding-left:50px; background-image:url(comp1.jpg);'>
	<br/><br/><br/><br/><br/><br/><br/><br/>
	<div style='width:90% ; background-image:url(comp2.jpg) ; border:2px solid black ; padding: 20px;'>
		<u><h2 style = ''><a href='index.php' style='text-decoration:none;color:black;font-size:25px'>Home</a></h2></u>

	<h1 style = 'color:white'>LOGIN HERE</h1>
		<form action='login.php' method='post'>
		<table>
			<tr>
				<td>
					<b>Username:</b>
				</td>
				<td>
					<input type='text' name='username' style='padding: 3px'>
				</td>
			</tr>
			
			<tr>
				<td>
					<b>Password:</b>
				</td>
				<td>
					<input type='password' name='password' style='padding: 3px'>
				</td>
			</tr>
			<tr></tr>
			<tr></tr>
			<tr>
				<td>
					<input type='submit' name='login' value='login'>
				</td>
			</tr>
			
		</table>
</div>

</body>
";
?>