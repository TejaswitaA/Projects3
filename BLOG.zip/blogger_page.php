<?php

// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");

error_reporting(0);

echo "
<body style='background-image:url(comp1.jpg);'>
<div style='padding-left:30px'>
	<div style = 'padding-left:30px ;padding-top:10px; background-color:black; width:95.1% ; height:1.5%'>
		<table>
			<tr>
				<td style='text-align:right ; width:1200px'>
					<a href='login.html' style='text-decoration:none ; color:white ; font-size:20px'>LOGIN</a>
				</td>
			</tr>
			<tr>
				<td style='text-align:right ; width:1200px'>
					<a href='register.php' style='text-decoration:none ; color:white ; font-size:20px'>REGISTER</a>
				</td>
			</tr>
		</table>
	</div>
	<div style = 'background-color:black ; width:97.45% ; height:8%'>
	<table style='padding-top:15px; padding-bottom:10px'>
		<tr>
			<td style='text-align:center ; width:150px'>
				<a href='index.php' style='text-decoration:none ; color:white ; font-size:20px'>Home</a>
			</td>
			<td style='text-align:center ; width:150px'>
				<a href='contact.php' style='text-decoration:none ; color:white ; font-size:20px'>Contact Us</a>
			</td>
		</tr>
	</table>
</div>
</div>
</body>
";

$sql = "SELECT * FROM blogger_info WHERE blogger_username <> 'Admin'";

$records = mysql_query($sql);

$a = 1;

while($row = mysql_fetch_assoc($records)){

	$a++;
	if($a == '2'){
		echo"
		<div style='padding-top:10px ; padding-left:30px'>
		<div style='background-color:black ; height:8% ; width:200px'>
			<h3 style='color:white ; text-align:center ; padding-top:10px'>BLOGGERS</h3>
		</div>
		</div>

		";
	}
	
	echo "
	<div style='padding-top:10px ; padding-left:30px'>
	<div style = 'width:30% ; background-color:grey ; border:1px solid black ; padding-left: 20px'>
		
		<table style='padding-top:15px; padding-bottom:10px'>
		<tr>
			<td style='text-align:right ; width:150px'>
				<h1 style = 'color:black ; font-size:20px'>ID:</h1>
			</td>
			<td style='text-align:left ; width:150px ; padding-left:10px'>
				<h1 style = 'color:black ; font-size:20px'>".$row['blogger_id']."</h1>
			</td>
		</tr>
		<tr>
			<td style='text-align:right ; width:150px'>
				<h1 style = 'color:black ; font-size:20px'>USERNAME:</h1>
			</td>
			<td style='text-align:left ; width:150px ; padding-left:10px'>
				<h1 style = 'color:black ; font-size:20px'>".$row['blogger_username']."</h1>
			</td>
		</tr>
	</table>
		
	</div>
	</div>
	</body>
	";
	
}

if($a == '1'){

	echo "
		<div style = 'padding-left:30px'>
		<div style='background-color:grey ; height:8% ; width:400px'>
			<h3 style='color:black ; text-align:center ; padding-top:10px'>NO BLOGGERS REGISTERED</h3>
		</div>
		</div>
		";

}

?>