<?php

session_start();
// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");

error_reporting(0);

$blogger_id = $_SESSION['blogger_id'];
$check = mysql_fetch_array(mysql_query("SELECT * FROM blogger_info WHERE blogger_id = '$blogger_id'"));

if($check['blogger_permission'] == 'no'){
	die("YOU DO NOT HAVE PERMISSION TO CREATE NEW BLOG.<a href='blogger.php'>Back</a>.");
}

echo "
<body style='background-image:url(comp1.jpg);'> 
<div style = 'width:90% ; background-color:grey ; border:2px solid black ; padding: 20px'>
		<h2 style = ''><a href='blogger.php' style='text-decoration:none;color:black;font-size:25px'>Home</a></h2>
		<form action='' method='post'>
		<table>
			<tr>
				<td>
					<b>Blog Title:</b>
				</td>
				<td>
					<input type='text' name='blog_title' style='padding: 3px'>
				</td>
			</tr>
			
			<tr>
				<td>
					<b>Blog Category:</b>
				</td>
				<td>
					<input type='text' name='blog_category' style='padding: 3px'>
				</td>
			</tr>
			
			<tr>
				<td>
					<b>Blog Description:</b>
				</td>
				<td>
					<textarea name='blog_desc' cols='80' rows='4'></textarea>
				</td>
			</tr>
			
			<tr>
				<td>
					<input type='submit' name='create' value='create'>
				</td>
			</tr>
			
		</table>
</div>
</body>
";

if($_POST['create']){
	
	$username = $_SESSION['blogger_username'];
	
	$get = mysql_fetch_array(mysql_query("SELECT * FROM blogger_info WHERE blogger_username = '$username'"));
	$title = $_POST['blog_title'];
	$category = $_POST['blog_category'];
	$author = $username;
	$desc = $_POST['blog_desc'];
	$id = $get['blogger_id'];
	time();
	$mysqldate = date( 'Y-m-d', time());
	
	mysql_query("INSERT INTO blogs (blogger_id , blog_title , blog_desc ,blog_category , blog_author , blog_is_active , creation_date , disp_permission) VALUES ('$id' , '$title' , '$desc' , '$category' , '$author' , 'yes' , '$mysqldate' , 'no')");
	
	
	if($username == 'Admin'){
		header('location:Admin.php');
	}
	else{
	header('location:blogger.php');
	}

}

?>