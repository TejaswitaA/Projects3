<?php

// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");
// echo "Successfully connected to the server and successfully connected to the database blog";

error_reporting(0);

if($_POST['contact']){
	
	$name = $_POST['name'];
	$num = $_POST['num'];
	$email = $_POST['email'];
	
	mysql_query("INSERT INTO viewer_contact_info (viewer_name , viewer_phn_no , viewer_email_id) VALUES ('$name' , '$num' , '$email')");
	
	header('location:index.php');
	
}

echo "
 
<body style ='padding-left:50px; background-image:url(comp1.jpg);'>
	<div style='width:90% ; background-color:grey ; border:2px solid black ; padding: 20px'>
		<h2 style = ''><a href='index.php' style='text-decoration:none;color:black;font-size:25px'>Home</a></h2>
		<h1 style = 'color:white'>CONTACT DETAILS</h1>
		<form action='' method='post'>
		<table>
			<tr>
				<td>
					<b>Name:</b>
				</td>
				<td>
					<input type='text' name='name' style='padding: 3px'>
				</td>
			</tr>
			
			<tr>
				<td>
					<b>Contact no.:</b>
				</td>
				<td>
					<input type='text' name='num' style='padding: 3px'>
				</td>
			</tr>
			
			<tr>
				<td>
					<b>Email Id:</b>
				</td>
				<td>
					<input type='text' name='email' style='padding: 3px'>
				</td>
			</tr>
			
			<tr>
				<td>
					<input type='submit' name='contact' value='Send'>
				</td>
			</tr>
			
		</table>
	</div>
</body>
";

?>