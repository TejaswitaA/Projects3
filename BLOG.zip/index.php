<?php

// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");

//echo "Successfully connected to the server and successfully connected to the database blog";

error_reporting(0);

echo "

<body style = 'background-image:url(comp1.jpg) ; '>
<div style='padding-left:30px'>
	<div style = 'padding-left:90px ;padding-top:10px; width:95% ; height:1.5%'>
		<table>
			<tr>
				<img src='blog3.jpg' >
			 </tr><br />
			<tr></div>
			<div style = 'padding-left:40px ;padding-top:10px; padding-bottom:80px; padding-right:40px width:95% ; height:1.5%'>
            <b><h1 style='text-align:center; color:black; font-size:65px;'><u>WeBloG !</u></h1></b><br/>
			</tr><br/><br/><br/><br/>
			<tr>
			<td style='text-align:left ; width:150px'>
				<u><b><a href='blogger_page.php' style='text-decoration:none ; color:#4d0026 ; font-size:20px; background-color:#ff6600;'>BLOGGERS</a></b></u>
			</td>
				<td style='text-align:right ; width:1200px'>
					<u><b><a href='login.php' style='text-decoration:none ; color:white ; background-color:blue; font-size:25px; '>LOGIN</a></b></u>
				</td>
			</tr>
			<tr>
				<td style='text-align:left ; width:170px'>
				<u><b><a href='contact.php' style='text-decoration:none ; color:#4d0026 ; font-size:20px; background-color:#ff6600;'>CONTACT US</a></b></u>
			</td>
				<td style='text-align:right ; width:1200px'>
					<u><b><a href='register.php' style='text-decoration:none ; color:white ; background-color:blue; font-size:25px; '>REGISTER</a></b></u>
				</td>
			</tr>	
		</table>
</div>
</div>
</body><br/><br/><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
";
$sql = "SELECT * FROM blogs";

$records = mysql_query($sql);

$a = 1;

while($row = mysql_fetch_assoc($records)){

	$a++;
	if($a == '2'){
		echo"
		<body><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		<div style='padding-top:10px ; padding-left:30px; align:center;'>
		<div style='background-color:black ; height:8% ; width:200px; align:center ;'>
			<h3 style='color:white ; text-align:center ; padding-top:10px;'>BLOGS</h3>
		</div>
		</div>
		";
	}
	if($row['disp_permission']== 'yes'){
	echo "
	<div style='padding-top:10px ; padding-left:30px'>
	<div style = 'width:60% ; background-image:url(bpattern.jpg) ; border:1px solid black ; padding: 20px; align:center;'>
		<h1 style = 'color:white ; font-size:20px ; padding:7px'>BLOG ID:  ".$row['blog_id']."</h1>
		<h1 style = 'color:white ;font-size:20px ; padding:7px'>BLOG AUTHOR: <a href='author_details.php?id=".$row['blog_author']."' style='text-decoration:none ;color:white;'>".$row['blog_author']."</a></h1>
		<h1 style = 'color:white ; font-size:20px ; padding:7px'>BLOG TITLE:  ".$row['blog_title']."</h1>
		<h1 style = 'color:white ; font-size:20px ; padding:7px'>BLOG CATEGORY:  ".$row['blog_category']."</h1>
		<h1 style = 'color:white ; font-size:20px ; padding:7px'>BLOG DESCRIPTION:  ".$row['blog_desc']."</h1>
		<h1 style = 'color:white; font-size:20px ; padding:7px'>BLOG CREATION DATE:  ".$row['creation_date']."</h1>
		<h1 style = 'color:white ; font-size:20px ; padding:7px'>BLOG UPDATED DATE:  ".$row['updated_date']."</h1>
		<h1 style = 'color:white ; font-size:20px ; padding:7px'>BLOG ACTIVE:  ".$row['blog_is_active']."</h1>
	";
			$bid = $row['blog_id'];
			$records1 = mysql_fetch_array(mysql_query("SELECT * FROM blog_detail WHERE blog_id = $bid"));
			$images = $records1['blog_detail_image'];
			echo " <img src='$images'>
			<br />
	</div></div>"; 
	$_SESSION['blog_author'] = $row['blog_author'];}
}

if($a == '1'){

	echo "
		<div style = 'padding-left:30px'>
		<div style='background-color:grey ; height:8% ; width:400px'>
			<h3 style='color:black ; text-align:center ; padding-top:10px'>NO BLOGS TO DISPLAY</h3>
		</div>
		</div></body>
		";

}

?>
