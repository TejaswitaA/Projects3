<?php

session_start();
// Create connection
$conn = mysql_connect("localhost","root","") or die("Couldn't connect to the server");

mysql_select_db("blog",$conn) or die("Couldn't connect to the database");
// echo "Successfully connected to the server and successfully connected to the database blog";

error_reporting(0);

echo "
	<body style='background-image:url(comp1.jpg);'>
	<div style = 'width:90% ; background-color:grey ; border:2px solid black ; padding: 20px'>
	<h2 style = ''><a href='admin.php' style='text-decoration:none;color:black;font-size:25px'>Home</a></h2>
	<form action='' method='post'>
	<h1 style = 'color:black ; font-size:20px'>BLOGGER_ID:  
	<input type='text' name='id' style='padding:3px'></h1>
	<input type='submit' name='edit' value='Edit'>
	
	</div>
	</body>
	";
	
	if($_POST['edit']){
		
		$blogger_id = $_POST['id'];

		$record = mysql_fetch_array(mysql_query("SELECT * FROM blogger_info WHERE blogger_id = '$blogger_id'"));
		if($record == 0){
			die("NO SUCH BLOGGER EXISTS. <a href='users.php'>Back</a>");
		}

		if($record['blogger_permission'] == 'no'){
			mysql_query("UPDATE blogger_info SET blogger_permission = 'yes' WHERE blogger_id = '$blogger_id'");
		}
		
		else if($record['blogger_permission'] == ''){
			mysql_query("UPDATE blogger_info SET blogger_permission = 'yes' WHERE blogger_id = '$blogger_id'");
		}

		else if($record['blogger_permission'] == 'yes'){
			mysql_query("UPDATE blogger_info SET blogger_permission = 'no' WHERE blogger_id = '$blogger_id'");
		}

		header('location:users.php');
	}
?>

