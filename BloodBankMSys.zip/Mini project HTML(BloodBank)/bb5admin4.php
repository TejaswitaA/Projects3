<head>
<style>
    .logout{
         text-align:center;
         font-size:50px;
         color:black;
     }
	 body{
	 background-image:url("blood8.jpg");
	 background-repeat:no-repeat;
	 background-size:100%;
	 background-attachment:fixed;
	 }
	 .big{
			font-size:30px;
			background-color:darkblue;
			color:lightblue;
	 }
	 .big2{
			font-size:30px;
			background-color:lightblue;
			color:darkblue;
	 }
	 .div2{
		 height:40px;
		 width:40px;
		 float:right;
	 }

</style>
</head>
<body>

<h1 class="logout">WELCOME USER</h1>
<form action="BB1_bloodbank_1.php">
<button class="big2" onclick="BB1_bloodbank_1.php"  style="float:right">LOGOUT</button>
</form>
<br />
<br />
<hr />
<br />
<br />
<br />
<form action="bb6bookform.php">
<button class="big" onclick="bb6bookform.php">ADD BLOOD BAG</button>
</form>
</body>
</html>