<html>
	<head>
		<title>
			SIGN_UP PAGE
		</title>
		<style>
		.error{
			color:red;
		}
		body{
			background-image:url(blood2.jpg);
			background-repeat:no-repeat;
			background-size:100%;
			background-attachment:fixed;
			background-position:0px -150px;
		}
		.part2{
			background-color:grey;
			color:white;
			padding:10px;
			padding-left:100px;
			padding-right:100px;
			margin-left:500px;
			margin-right:500px;
			border-width:5px;
			border-color:white;
		}
		#part1{
			
			color:white;
			margin-left:auto;
			margin-right:auto;
		}
		</style>
	</head>

<body>

<h1 id="part1" align="center">Welcome to Blood bank</h1>


<center>Your Login Id is: <?php echo $_POST["id"}; ?> </center>

	<script type="text/javascript">
		function validateForm() {
			var re=/^[\w ]+$/;
    		var x = document.getElementById("A").value;
   			if (x == null || x == "") {
        		alert("USER_NAME must be filled out");
        		return false;
   			}
			if(/\d/.test(x))
			{
				alert("Name is INVALID");
				return false;
			}
			if(!re.test(x))
			{
				alert("Error:USER_NAME contains INVALID characters");
				return false;
			}
			
			
   			var y = document.getElementById("B").value;
        	if(y == null || y == ""){
        		alert("Provide Bank Name");
        		return false;
        	}
			
        	var a = document.getElementById("C").value;
        	if(a== null || a=="" ){
        		alert("Enter City name");
        		return false;
        	}
			
		var b = document.getElementById("C").value;
        	if(b== null || b=="" ){
        		alert("Enter State name");
        		return false;
        	}
		
		}
	</script>
		
		<p  align="center" id="part1"><b>The field with ' <span class="error">*</span> ' mark is reqired</b></p>
		<form name="myForm" action="BB3.php" onsubmit="return validateForm()" method="post">
			<div class="part2" >
			<TABLE width="50%">
				<tr>
					<td>BLOOD_BANK_ID<span class="error">*</span>:</td>
					<td>
						<input type="text" name="userid" id="A"/> </td>
				</tr>
				<tr>
					<td>Blood_Bank_NAME<span class="error">*</span>:</td>
					<td> <input type="text" name="bankName" id="B"/></td>
				</tr>

				<tr>
					<td>City<span class="error">*</span>:</td>
					<td> <input type="text" name="city" id="C"/></td>
				</tr>
				<tr>
					<td>State<span class="error">*</span>:</td>
					<td> <input type="text" name="state" id="D"/></td>
				</tr>
				
			</table>
			</div>
			<p align="center">
			<input type="submit"value="Submit" />
			<input type="reset" value="Reset" />
			</p>
		
		</form>

	</body>
</html>