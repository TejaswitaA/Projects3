<?php
session_start();
	if($_SERVER["REQUEST_METHOD"]=="POST"){
		$searchitem = implode(",",$_POST);
		$handle = @fopen("data.txt","r");
		if($handle){
			while(!feof($handle)){
				$buffer = fgets($handle);
				
				//preg_replace will remove the space btw words
				$str = preg_replace('/\s++/','',$buffer);
				
				if(strcmp($str,$searchitem)==0){
					session_start();
					$_SESSION["username"] =$_POST["username"];
					$matches = $str;
					if($_SERVER["REQUEST_METHOD"]=="POST"){
		$searchitem = implode(",",$_POST);
		$handle = @fopen("admin.txt","r");
		if($handle){
			while(!feof($handle)){
				$buffer = fgets($handle);
				
				//preg_replace will remove the space btw words
				$str = preg_replace('/\s++/','',$buffer);
				if(strcmp($str,$searchitem)==0){
					session_start();

					$matches = $str;
					echo "You are admin.";
					echo "<br>".$str;

				}
			}
		}
	}
					header("Location:BB4.1_bloodbags.php");
				}
			}
		}
	}
?>	