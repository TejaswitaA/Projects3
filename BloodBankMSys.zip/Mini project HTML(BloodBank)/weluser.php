<html>
<style>
	.abc{
		font-size:20px;
	}
</style>
<body>
<form  action="BB1_bloodbank_1.php">
<button class="abc"onclick="BB1_bloodbank_1.php" style="float:right">LOG OUT</button>
</form>
<br />
<br />
<hr />
<br />
<form class="abc" action="getinfo.php">
<button class="abc"onclick="#">GET INFORMATION ABOUT YOUR ACCOUNT </button>
</form>
</body>
</html>
