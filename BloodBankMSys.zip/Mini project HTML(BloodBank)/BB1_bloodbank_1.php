<!DOCTYPE html>	
<html>
<head><title> BLOOD BANK :) </title>

	<style>
		#container{
		width:100%;
		height:auto;
		}
		#top-banner{
		height:150px;
		width:100%;
		background-color:red;
		}
		#main{
		height:400px;
		width:66%;
		background-color:red;
		margin-left:17%;
		float:center;
		}
		#footer{
		width:100%;
		height:150px;
		background-color:red;
		}
	</style>
	
	<script>
		function validateForm() {
        	var a = document.getElementById("loginid").value;
        	if(a== null || a=="" ){
        		alert("Entering Login ID is must");
        		return false;
        	}
			var re=/^[\w ]+$/;	
		var y = document.getElementById("password").value;
        	if(y == null || y == ""){
        		alert("PASSWORD is must");
        		return false;
        	}
		}

	</script>

</head>      



<body bgcolor="red">

<div id="container">
<div id="top-banner">

<table width="100%">
	<tr>	
		<td width="17%"><marquee direction="right"><img src="http://www.bishopbenzigerhospital.com/images/slides/blood-bank_-_2014-04-21__06_57_20.jpeg" height="125px" width="50%">/<marquee></td>
	</tr>
</table>
</div>


<div id="main">
<h1 align="center">Welcome</h1>
	<center><h2>Blood bank registration </h2></center>
		<form name ="myForm" action="submit.php" onsubmit ="return validateForm()" enctype="multipart/form-data" method="post">
			<table border="0" width="50%" col="2" align="center">
			
			<tbody>
			<tr>
			<td><h3><b>Login ID</b></h3></td>
			<td>:</td><td><input type="text" ID="loginid" name="loginid" size="40"></td>
			</tr>
			
			
			<tr>
			<td><h3><b>Password</b></h3></td>
			<td>:</td><td><input type="password" ID="password" name="password" size="40"></td>
			</tr>
			</tbody></table>
	
			<center><input type="submit" name="submit" value="Login" /> </center> 	
		</form>
		<ul align="center">
		<li><a href="BB2.php">SIGN UP</a>
			</li>
		</ul>
</div>

<div id="footer">
<img src="http://sahyadrihospital.com/wp-content/uploads/2013/10/bloodBank.jpg" height="140px" width="100%">
</div>

</body>
</html>
