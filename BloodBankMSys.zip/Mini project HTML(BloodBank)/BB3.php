<?php
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$a=array();
$b=array();
$c=array();
$d=array();
$e=array();
$f=0;
	
	$handle= @fopen("bloodbagissue.txt","r");
	$i=0;
		$search= $_POST['blood_group'];
		if($handle)
		{
			while(!feof($handle)){
				$buffer=fgets($handle);
				list($a[$i],$b[$i],$c[$i],$d[$i])=split(",",$buffer);
					
				if(strcmp($search,$c[$i])==0||strcmp($search,$d[$i])==-2){
					$e[$j]=$i;
					$j++;
					$f=1;
					break;
					}
				$i++;
			}
			ECHO "<br> <br>";
		}
		if($f==1) header("Location:BB4.1_bloodbags.php");
		else {
	$myFile = "bloodbagissue.txt";
	$fh = fopen($myFile,'a');
	fwrite($fh,"\n");
	$c = implode(",",$_POST);
	fwrite($fh, $c);
	fclose($fh);
	header("Location:BB4.2_issued.php");
		}
		
		fclose($handle);
}
?>