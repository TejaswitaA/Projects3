<html>
<style>
	body{
			background-image:url(blood6.jpg);
			background-color:black;
			background-repeat:no-repeat;
			background-size:100%;
			background-attachment:fixed;
			background-position:0px -150px;
		}
		h1{
			color:white;
		}
 .big2{
			font-size:25px;
			background-color:grey;
			color:black;
	 }
</style>
	<body>
		<H1> YOU HAD SUCCESSFULLY ISSUED THE BLOOD BAG</H1>
		<form action="BB4.1_bloodbags.php">
	<button class="big2">BACK</button>
	</form>
	</body>
</html>