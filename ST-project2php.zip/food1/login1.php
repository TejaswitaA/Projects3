<?php

session_start();
// Create connection
$connect= mysqli_connect("localhost","root","","food ordering") or die("Couldn't find...");

error_reporting(0);

        session_unset();
		session_destroy();
		session_start();
		
if(isset($_POST['submit'])){
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	$query=mysqli_query($connect,"SELECT * FROM customer WHERE email='$email'");
	$numrows=mysqli_num_rows($query);
	if($numrows!==0){
		while($row=mysqli_fetch_assoc($query)){
			$dbemail = $row['email'];
			$dbpassword=$row['password'];
			$cid=$row['srno'];
		}
	if($numrows == 0){
		die("NO SUCH ACCOUNT EXISTS. CLICK <a href='register.php'>Here</a> TO REGISTER NOW.");
	}
	
	
	
	
	if($email==$dbemail  && ($password==$dbpassword)){
	
$query1=mysqli_query($connect,"CREATE TABLE `".$cid."`(
	cid int(250),
	pid int(250),
	name varchar(250),
	image varchar(250),
	price int(250),
	quantity int(250),
	subtotal int(250)
)");
// sql to create table


if ($query1) {
   // echo "Table MyGuests created successfully";
} 
else {
    echo "Error creating table: " . $conn->error;
}


			header("location:account.php");
			echo "You are logged in!";
			@$_SESSION['email']=$email;
		
			
		}
		else
			echo "your password is incorrect";
	}
	else
	{
		echo "That user doesn't exist!";
		//<html><a href="intialpage_lib.php">go back to home page</a></html>
	}
}


?>

<!DOCTYPE html>
<html>
<head>
	<title>foodie || Login</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="productstyle.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="home.php">Home</a>
		</div>
		<div>
		<ul class="nav navbar-nav navbar-right">
			<!---<li><a href="admin.php"><span class="glyphicon glyphicon-wrench"></span> Admin</a></li>-->
			<li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
			<li class="active"><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
		</ul>
	</div>
</nav>

  <div class="modal-dialog">
  
     
          <h1 class="text-center">Log In</h1>
          <form class="form col-md-12 center-block" action="login.php" method="post">
            <div class="form-group">
              <input type="text" class="form-control input-lg" name="email" placeholder="email">
            </div>
            <div class="form-group">
              <input type="password" class="form-control input-lg" name="password" placeholder="Password">
            </div>
            <div class="form-group">
				<input id="button" type="submit" name="submit" class="btn btn-success btn-lg btn-block" value="Log-In">
              
              <span class="pull-right"><a href="signup.php">Register Here!!</a></span>
			  <!----<span><?php echo $error; ?></span>--->
            </div>
          </form>
      </div>
      
  </div>
  </div>
</div>


      
  </div>
  </div>
</div>




</body>
</html>