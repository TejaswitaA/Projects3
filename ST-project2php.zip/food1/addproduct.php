<?php
session_start();
//echo"".$_SESSION['blogger_mailid']."!";
?>
<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
		<a class="navbar-brand" href="admin.php">Back</a>
		</div>
		

</nav>

<form action="addproductdata.php" class="form col-md-12 center-block" enctype="multipart/form-data" method="post" ><center>
<h1>Product</h1>
<div class="form-group"><center>
<input type="text" name="name" class="form-control input-lg"  style="width:500px;" placeholder="Name" ><br></div>
<div class="form-group">
<center>


<input type="text" class="form-control input-lg" name="desc" rows="4" cols="50" style="width:500px ;" placeholder="Description">
</textarea><br></div>
<div class="form-group">
<center>
<input type="text" name="price" class="form-control input-lg" style="width:500px;" placeholder="price"><br></div
div class="form-group">
<center>
<input type="text" name="type" class="form-control input-lg" style="width:500px;" placeholder="type"><br></div>
<div class="form-group">
<center>
<input type="text" name="quantity" class="form-control input-lg" style="width:500px;" placeholder="quantity"><br></div>
<div class="form-group">
<center>
<input type="text" name="recmnd" class="form-control input-lg" style="width:500px;" placeholder="recommend"><br></div>
<div class="form-group">
<center>

<input type="file" name="fileToUpload" id="fileToUpload"  class="form-control input-lg" style="width:500px;"/>    </div>
<div class="form-group">

<center>
 <div class="form-group"><input type="submit" value="submit" name="submit"  class="form-control input-lg" style="width:500px;" /></div>

</div>
</center>
</div>
</form>

</body>
</html>
