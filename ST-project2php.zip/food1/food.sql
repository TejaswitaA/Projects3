-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2016 at 07:19 AM
-- Server version: 5.7.11
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `srno` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(10) NOT NULL,
  `city` varchar(30) NOT NULL,
  `location` varchar(30) NOT NULL,
  `flatno` varchar(50) NOT NULL,
  `mobileno` int(100) NOT NULL,
  `points` int(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`srno`, `firstname`, `lastname`, `email`, `password`, `city`, `location`, `flatno`, `mobileno`, `points`) VALUES
(3, '', '', '', '', '', '', '', 8, 0),
(2, 'meenu', 'agarwal', 'mee.agarwal@gmail.com', 'meenu', 'surat', 'piplod', '223', 123456, 0),
(4, 'tejal', 'malar', 'tejalmalar@gmailcom', 'tejal', 'personal', 'sdfjkhsdjfk', '123', 123, 0),
(1, 'admin', 'admin', 'asdf@gmail.com', 'admin0000', 'Surat', 'Piplod', '123', 1234566789, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(25) NOT NULL,
  `image` varchar(255) NOT NULL,
  `name` varchar(200) NOT NULL,
  `content` varchar(200) NOT NULL,
  `price` int(200) NOT NULL,
  `date` datetime(6) NOT NULL,
  `quantity` int(25) NOT NULL,
  `type` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `image`, `name`, `content`, `price`, `date`, `quantity`, `type`) VALUES
(1, 'paneer_pestoni.jpg', 'paneer', 'kadhai paneer', 120, '2016-10-01 00:00:00.000000', 0, ''),
(2, 'kadhai_paneer-wo_paan.jpg', 'khana khazana ', 'paneer palak', 140, '2016-10-06 00:00:00.000000', 0, ''),
(3, 'deccan_delight.jpg', 'tatata', 'poansk;x', 140, '2016-10-06 00:00:00.000000', 0, ''),
(4, 'mehbooba_o_mehbooba.jpg', 'idli', 'south indian dish', 50, '2016-10-07 00:00:00.000000', 50, 'breakfast');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`email`),
  ADD KEY `index` (`srno`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `srno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
