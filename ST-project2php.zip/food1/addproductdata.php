<?php
	session_start();
$name=$_POST['name'];
$desc=$_POST['desc'];
$price=$_POST['price'];
$type=$_POST['type'];
$quantity=$_POST['quantity'];
$recmnd=$_POST['recmnd'];
$target_dir="uploaded/";
$image=basename($_FILES["fileToUpload"]["name"]);
$target_file=$target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk=1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
if($uploadOk==0){
	
}
else{
	if(move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],$target_file)){
		//echo"successful";
	}
	
}

if($price && $desc && $date && $name && $image && $quantity && $type ){
	$connect= mysqli_connect("localhost","root","","food") or die("Couldn't find...");
		
		
	
		 $query1=mysqli_query($connect,"INSERT INTO tbl_product(name,content,price,image,product_type,quantity,recomnd) VALUES('$name','$desc','$price','$image','$type','$quantity','$recmnd')");
	if($query1){
				echo"successfully added";
				header('Refresh: 5;URL=http://localhost/food1/admin.php');
				
			}
}
else
{
	echo"fail";
}
?>
<html>
<head>
</head>
<body>
<p>hello</p>
</body>
</html>