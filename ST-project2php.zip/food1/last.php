<?php
session_start();
$cid=$_SESSION['cid'];
$oid=$_SESSION['oid'];
?>

<?php
$connect = mysqli_connect("localhost","root", "", "food");
// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}
$query=mysqli_query($connect,"SELECT * FROM delivery_info WHERE oid='$oid'");
	$row = mysqli_fetch_assoc($query);
			$oid=$row['oid'];
			$cid=$row['cid'];
			$firstname=$row['firstname'];
			$lastname=$row['lastname'];
		$time=$row['delivery_time'];
			$city=$row['city'];
			$location=$row['location'];
			$mobileno=$row['mobileno'];
			$flatno=$row['flatno'];
	


$result1 = mysqli_query($connect,"SELECT SUM(subtotal) AS value_sum FROM `".$cid."`"); 
$row3 = mysqli_fetch_assoc($result1); 
$sum = $row3['value_sum'];	
?>

<html>
<head>
	<title>foodie</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<style>
	

	</style>
</head>
<body background="admin1.jpg">
<script> alert("Payment is SUCCESSFUL") </script>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
			<ul class="nav navbar-nav navbar-right">
			<li class="active"><a href="logout.php?logout=<?php echo $cid;?>">logout</a></li>
			</ul>
		
	</div>
	
</nav>

 <div class="fo"><center><br><br><br><br>
								<h1><u>ORDER REVIEW</u></h1><br><br><br><br>
                               <form method="post" action="editprofile.php">
                               <h4 class="text-info">Name : <?php echo $firstname.$lastname ?></h4>  
							   
								
                                
							    <h4 class="text-info">City  : <?php echo $city ; ?></h4> 
								<h4 class="text-info">Location : <?php echo $location ; ?></h4> 
					 <h4 class="text-info">Flat-No : <?php echo $flatno; ?></h4> 
					 <h4 class="text-info">Contact : <?php echo $mobileno; ?></h4>
					  <h4 class="text-info">Delivery Time: <?php echo $time; ?></h4>
					                                    
			</form>	
                                </div>
                          <?php
                        $result = mysqli_query($connect,"SELECT * FROM `".$cid."`"); 
while($row2=mysqli_fetch_assoc($result)){ 
$pname=$row2['name'];
$quantity=$row2['quantity'];
$price=$row2['price'];
$subtotal=$row2['subtotal'];
	
					 ?> <center><table border=2px width=25%>
					   <tr>
					<td style="width:50%">	<?php echo $pname; 	?> </td>    
						<td style="width:10;">  <?php echo $quantity; ?></td>
                       <td style="width:20;"> <?php echo $price; ?>  </td>
						<td style="width:20"><?php   echo $subtotal;?> </td>
						</tr>
						  </table><?php
}
?><center>
<table border=2px width=25%>
 <tr><td colspan=4><b>Total:<?php echo $sum; ?></b></td></tr>
						</table>  
           	

</center>

</body>
</html>

