
<?php
//include('config.php');
if(isset($_SESSION['login_user'])){
header("location: index.php");
}

session_start();

	$connect= mysqli_connect("localhost","root","","food") or die("Couldn't find...");

	session_unset();
	session_destroy();
	session_start();	
	
	if(isset($_POST['submit'])){
		
		$email=$_POST['email'];
		$password=md5($_POST['password']);
		
		
		if($email && $password ){
		if($email=="admin@gmail.com" && $password="admin" ){
		header("location:admin.php");
		}
		
	$query=mysqli_query($connect,"SELECT * FROM customer WHERE email='$email'");
	$numrows=mysqli_num_rows($query);
	if($numrows!==0){
		while($row=mysqli_fetch_assoc($query)){
			$dbemail = $row['email'];
			$dbpassword=$row['password'];
			$cid=$row['srno'];
		}
		if($email==$dbemail  && ($password==$dbpassword)){
				
			$query1=mysqli_query($connect,"CREATE TABLE `".$cid."`(
				cid int(250),
				pid int(250),
				name varchar(250),
				image varchar(250),
				price int(250),
				quantity int(250),
				subtotal int(250)
			)");
			// sql to create table


			if ($query1) {
			   // echo "Table MyGuests created successfully";
			} 
			else {
				echo "Error creating table: " . $conn->error;
			}

						$_SESSION['email']= $email;
						header("location:account.php");
						echo "You are logged in!";
						
					
						
					}
					else
						echo "your password is incorrect";
				}
				else
				{
					echo "That user doesn't exist!";
				}
				
			}
			else{
			die("Please enter a username!");
			}
	}
	

?>
<!DOCTYPE html>
<html>
<head>
	<title>foodie || Login</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="home.php">Home</a>
		</div>
		
	<div>
		<ul class="nav navbar-nav navbar-right">
			<!---<li><a href="admin.php"><span class="glyphicon glyphicon-wrench"></span> Admin</a></li>-->
			<li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
			<li class="active"><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
		</ul>
	</div>
</nav>

  <div class="modal-dialog">
  
     
          <h1 class="text-center">Log In</h1>
          <form class="form col-md-12 center-block" action="login.php" method="post">
            <div class="form-group">
              <input type="text" class="form-control input-lg" name="email" placeholder="email" required>
            </div>
            <div class="form-group">
              <input type="password" class="form-control input-lg" name="password" placeholder="Password" required>
            </div>
            <div class="form-group">
				<input id="button" type="submit" name="submit" class="btn btn-success btn-lg btn-block" value="Log-In">
              
              <span class="pull-right"><a href="register.php">Register Here!!</a></span>
			  <!----<span><?php echo $error; ?></span>--->
            </div>
          </form>
      </div>
      
  </div>
  </div>
</div>


      
  </div>
  </div>
</div>




</body>
</html>