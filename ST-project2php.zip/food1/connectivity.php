<?php
session_start();

	$connect= mysqli_connect("localhost","root","","food") or die("Couldn't find...");

	session_unset();
	session_destroy();
	session_start();	
	
	if(isset($_POST['submit'])){
		
		$email=$_POST['email'];
		$password=md5($_POST['password']);

		if($email && $password ){
		if($email=="admin@gmail.com" && $password="21232f297a57a5a743894a0e4a801fc3" ){
		header("location:admin.php");
		}
		
	$query=mysqli_query($connect,"SELECT * FROM customer WHERE email='$email'");
	$numrows=mysqli_num_rows($query);
	if($numrows!==0){
		while($row=mysqli_fetch_assoc($query)){
			$dbemail = $row['email'];
			$dbpassword=$row['password'];
			$cid=$row['srno'];
		}
		if($email==$dbemail  && ($password==$dbpassword)){
				
			$query1=mysqli_query($connect,"CREATE TABLE `".$cid."`(
				cid int(250),
				pid int(250),
				name varchar(250),
				image varchar(250),
				price int(250),
				quantity int(250),
				subtotal int(250)
			)");
			// sql to create table


			if ($query1) {
			   // echo "Table MyGuests created successfully";
			} 
			else {
				echo "Error creating table: " . $conn->error;
			}

						$_SESSION['email']= $email;
						echo "You are logged in!";
						header("location:account.php");
						
						
					
						
					}
					else
						echo "your password is incorrect";
				}
				else
				{
					echo "That user doesn't exist!";
				}
				
			}
			else{
			die("Please enter a username!");
			}
	}
	
?>