
<?php
//	include('signuconfig.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Blogger || Signup</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="home.php">Home</a>
		</div>
		
</nav>


  <div class="modal-dialog">
  
     
          <h1 class="text-center">Sign Up</h1>
          <form class="form col-md-12 center-block" method="post" action="registerdata.php">
		 
            <div class="form-group">
              <input type="text" class="form-control input-lg" name="firstname" placeholder="firstname" required>
            </div>
			<div class="form-group">
              <input type="text" class="form-control input-lg" name="lastname" placeholder="lastname" required>
            </div>
            <div class="form-group">
              <input type="password" class="form-control input-lg" name="password" placeholder="Password" required>
            </div>
			
			<div class="form-group">
				<input type="email" class="form-control input-lg" name="email" placeholder="email" required>
			</div>
			<div class="form-group">

  <select name="city" class="form-control input-lg" placeholder="city" required>
  <option value="Ahembdabad">Ahmedabad</option>
  <option value="Surat">Surat</option>
  <option value="Vadodara">Vadodara</option>
  
</select><br>
              <input type="text" class="form-control input-lg" name="location" placeholder="location" required>
            </div>
			
			<div class="form-group">
              <input type="text" class="form-control input-lg" name="flatno" placeholder="flatno" required>
            </div>
			<div class="form-group">
			
              <input type="text" class="form-control input-lg" name="mobileno" placeholder="mobileno" required>
            </div>
			
            <div class="form-group">
				<input id="button" type="submit" name="submit" class="btn btn-success btn-lg btn-block" value="Sign-Up">
              
              <span class="pull-right"><a href="login.php">Already Registered! Login Here</a></span>
			 <!---<span><?php echo $error; ?></span>-->
            </div>
          </form>
      </div>
      
  </div>
  </div>
</div>



</body>
</html>

