<?php
session_start();

if(isset($_POST['submitt'])){
$name=$_POST['name'];

if($name ){
	$connect= mysqli_connect("localhost","root","","food") or die("Couldn't find...");
		
		
	
		 $query1=mysqli_query($connect,"DELETE from tbl_product where name='$name'");
	if($query1){
				echo"successfully deleted";
				header('Refresh: 5;URL=http://localhost/food1/admin.php');
				
			}
		
	
}
else
{
	echo"fail";
}
}
?>

<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<title>Delete Product</title>
</head>
<body>
<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
		<a class="navbar-brand" href="admin.php">Back</a>
		</div>
		

</nav>

<form action="delete_product.php" class="form col-md-12 center-block" enctype="multipart/form-data" method="post" ><center>
<h1>Product</h1>
<div class="form-group"><center>
<input type="text" name="name" class="form-control input-lg"  style="width:500px;" placeholder="Name" ><br></div>

<div class="form-group">

<center>
 <div class="form-group"><input type="submit" value="submit" name="submitt"  class="form-control input-lg" style="width:500px;" /></div>

</div>
</center>
</div>
</form>

</body>
</html>
