<?php   
 session_start();  
 
 $connect = mysqli_connect("localhost", "root", "", "food ordering");  
 if (!$connect) 
{
    die("Connection failed: " . mysqli_connect_error());
}
	//$username = $_SESSION['username'];
                
			$query = "SELECT * FROM card_payment where username='Tejaswita@gmail.com'";  
            $result = mysqli_query($connect, $query);  
                if(mysqli_num_rows($result) > 0)  
                {  
                    $row = mysqli_fetch_array($result);
					$username = $row['username']; 
					$card_pass = $row['card_password'];
					$card_type = $row['card_type'];			
					$card_no = $row['card_no'];
					$cvv = $row['cvv_no'];
				}
if(isset($_POST['submit']))
{
	
	$pusername = $_POST['username']; 
	$pcard_pass = $_POST['password']; 
	$pcard_type = $_POST['ctype'];
	$pcard_no = $_POST['cardno']; 
	$pcvv = $_POST['cno']; 
}
	if(($pusername==$username)&&($pcard_pass==$card_pass)&&($pcard_type==$card_type)&&($pcard_no==$card_no)&&($pcvv==$cvv)){
		$message = "This amount of money deducted from your bank account.";
		echo "<script type='text/javascript'>alert('$message');</script>";
		header('location:order_review.php');
	}
	else{
		$message = "Card details did not match with BANK database.";
		echo "<script type='text/javascript'>alert('$message');</script>";
		die("<a href='card_pay.php'>Back to Payment details</a>");
	}
?>
 
 <html>  
      <head>  
           <title>Webslesson Tutorial | Simple PHP Mysql Shopping Cart</title>  
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
			<style>
		   
		.container{
			background-color: black;
			margin:0px;
			margin-top:10%;
			padding:0px;
			border: 1px solid black;
			height: 60%;
			z-index:-500;
		}
		
		ul {
		list-style-type: none;
		margin: 0px;
		padding: 0px;
		overflow: hidden;
		background-color: #5ed986;
		}

		li {
			float: left;
		}

		li a, .dropbtn {
			display: inline-block;
			color: white;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
			font-size:18px;
		}

		li a:hover, .dropdown:hover .dropbtn {
			background-color: gray;
			text-decoration:none;
		}

		li.dropdown {
			display: inline-block;
		}

		.dropdown-content {
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			text-decoration:none;
		}

		.dropdown-content a {
			color: #333;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			text-align: left;
			text-decoration:none;
		}

		.dropdown-content a:hover {background-color: gray;text-decoration:none;color:white;}

		.show {display:block;text-decoration:none;}
		}
		</style>
		   
      </head>  
      <body>

			<ul>
		<li style="float:right"><a href="about.asp">Log Out</a></li>
	</ul>
           <br />  
		   <table width="80%">
		   <tr>
                <form method='post' action='card_pay.php'>
                   <td> <div style="border:0px solid #333; background-color:white; border-radius:5px; padding:75px;height:500px;">
						<div class="modal-dialog">
						<h3 class="text-center">Card Details</h3>
				   	
							 Username:<input type="text" class="form-control input-lg" name="username" placeholder="name@gmail.com" ><br/>
							 Card Password:<input type="text" class="form-control input-lg" name="password" placeholder=""><br/>
							 Card Type:<input type="text" class="form-control input-lg" name="ctype" placeholder=""><br/>
							 Card No.:<input type="text" class="form-control input-lg" name="cardno" placeholder=""><br/>
							 CVV No.:<input type="text" class="form-control input-lg" name="cno" placeholder=""><br/>
							<input  id="button" type="submit" name="submit" class="btn btn-success btn-lg btn-block" value="Payment">
							
					</div>
				  </div>
				</td>
				</form>  
			</tr>
		</table>
	</body>
</html>
