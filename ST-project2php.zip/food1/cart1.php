<?php
session_start();
$cid=$_SESSION['cid'];
echo $cid;
?>