package com.metacube.hostelmanagement.facade;

import com.metacube.hostelmanagement.db.dao.LoginDAO;
import com.metacube.hostelmanagement.db.dao.ComplaintsDAO;
import com.metacube.hostelmanagement.vo.ComplaintVO;
import com.metacube.hostelmanagement.vo.LoginVO;
import com.metacube.hostelmanagement.vo.SignupVO;

public class LoginFacade {
	
	public boolean authenticate(LoginVO loginVO) {
		boolean authenticated = false;
		LoginDAO loginDAO = new LoginDAO();
		
		LoginVO loginVOFromDB = loginDAO.getLoginByUsername(loginVO.getUsername());
		if(loginVOFromDB != null) {
			if(loginVO.getPassword().equals(loginVOFromDB.getPassword())) {
				authenticated = true;
			}
		}
		return authenticated;
	}
	
	public boolean authenticate(SignupVO signupVO) {
	
		boolean authenticated = false;
		LoginDAO loginDAO = new LoginDAO();
	
		SignupVO signupToDB = loginDAO.getSignupByUserCheck(signupVO.getUsername());
		
		if(signupToDB != null){
			authenticated = false;
		}
		else if(signupToDB == null){
			authenticated=true;
		}
		return authenticated;
	}	

	public boolean authenticate (ComplaintVO complaintVO){
		boolean authenticated = false;
		ComplaintsDAO complaintsDAO = new ComplaintsDAO();
		
		ComplaintVO complaintToDB = complaintsDAO.getCheck(complaintVO.getComplaint());
		
		if(complaintToDB != null){
			authenticated = true;
		}
		return authenticated;
	}
}
