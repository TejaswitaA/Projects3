package com.metacube.hostelmanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.metacube.hostelmanagement.facade.LoginFacade;
import com.metacube.hostelmanagement.vo.LoginVO;

/**
 * Servlet implementation class LoginController
 */
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("login.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		LoginVO loginVO = new LoginVO();
		response.setContentType("text/html");
		//PrintWriter out = response.getWriter();

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String check = username;
		String pcheck = password;
		
		if (username == "" || password == "") {
			request.setAttribute("message",
					"Please enter some valid username and password");
			request.getRequestDispatcher("login.jsp")
					.forward(request, response);
		}
		loginVO.setPassword(password);
		loginVO.setUsername(username);

		LoginFacade loginFacade = new LoginFacade();
		boolean authenticated = loginFacade.authenticate(loginVO);

		int count = 0;
		HttpSession session=request.getSession(); 
		if(count>=3){
			authenticated=false;
		}

		if (authenticated) {
			request.setAttribute("message", "Welcome " + username);
			request.setAttribute("display", "Name :- " + username);
			request.getRequestDispatcher("success.jsp").forward(request,
					response);
			
		} else {
			if(count<3){
			request.setAttribute("message",
					"Please enter valid username and password");
			request.getRequestDispatcher("login.jsp")
					.forward(request, response);
			while(check==username && pcheck!=password){
				count=count++;
				}}
			else {
				request.setAttribute("message",
						"Your account is blocked");
				request.getRequestDispatcher("accntBlk.html")
						.forward(request, response);
			}
		}
			System.out.println(count);
		}

	}

