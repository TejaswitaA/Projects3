package com.metacube.hostelmanagement.controller;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import com.metacube.hostelmanagement.facade.LoginFacade;
//import com.metacube.hostelmanagement.vo.LoginVO;



import com.metacube.hostelmanagement.facade.LoginFacade;
import com.metacube.hostelmanagement.vo.LoginVO;
import com.metacube.hostelmanagement.vo.SignupVO;

/**
 * Servlet implementation class signupController
 */
public class signupController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("SignUp.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		SignupVO signupVO = new SignupVO();
		//PrintWriter out = response.getWriter();
		response.setContentType("text/html;charset=UTF-8");

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String roomNo = request.getParameter("roomNo");
		String rollNo = request.getParameter("rollNo");
		String phoneNo = request.getParameter("phoneNo");
		String year = request.getParameter("year");
		String branch = request.getParameter("branch");
		String image = request.getParameter("image");
		
		if ((username=="") ||(password.equals("")) || (roomNo.equals(""))
				|| (phoneNo.equals(""))|| (rollNo.equals(""))|| (year.equals(""))
				||( branch.equals(""))) {
			request.setAttribute("message", "Please FILL all the Compulsary details");
			request.getRequestDispatcher("SignUp.jsp").forward(request,
					response);
			System.out.println("All Fields are COMPULSARY !!");
		} 
		
		else {
			signupVO.setPassword(password);
			signupVO.setUsername(username);
			signupVO.setRoomNo(roomNo);
			signupVO.setRollNo(rollNo);
			signupVO.setPhoneNo(phoneNo);
			signupVO.setYear(year);
			signupVO.setBranch(branch);
			signupVO.setImage(image);
			
			LoginFacade loginFacade = new LoginFacade();
			boolean authenticated = loginFacade.authenticate(signupVO);
			
			if (authenticated==true) {
				try{
					System.out.println("Welcome !"+username);
					Class.forName("com.mysql.jdbc.Driver");
					
					Connection myConn=DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","oracle");
					 String updateString ="INSERT INTO demo.login (user,pass,rollNo,roomNo,phoneNo,year,branch,image) VALUES (?,?,?,?,?,?,?,?)";

				        PreparedStatement preparedStatement = myConn.prepareStatement(updateString);
				       
				        preparedStatement.setString(1, username);
				        preparedStatement.setString(2, password);
				        preparedStatement.setString(3, rollNo);
				        preparedStatement.setString(4, roomNo);
				        preparedStatement.setString(5, phoneNo);
				        preparedStatement.setString(6, year);
				        preparedStatement.setString(7, branch);
				        preparedStatement.setString(8, image);
				        int i = preparedStatement.executeUpdate();
				
					if(i>0)
					{
					  System.out.println("You are sucessfully registered");
					}
				}
				
				catch(Exception se)
				{
				  se.printStackTrace();
				}
				
				request.setAttribute("message", "Welcome  " + username+ " !!");
				request.setAttribute("display", "Name :- " + username);
				request.getRequestDispatcher("success.jsp").forward(request,
						response);
			} else {
				request.setAttribute("message","*Account with this username exist already, use different name*");
				request.getRequestDispatcher("SignUp.jsp").forward(request,response);
			}
		}
	}

}